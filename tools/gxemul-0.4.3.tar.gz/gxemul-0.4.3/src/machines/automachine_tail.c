
	/*  $Id: automachine_tail.c,v 1.1 2005/12/20 21:19:17 debug Exp $  */
}

