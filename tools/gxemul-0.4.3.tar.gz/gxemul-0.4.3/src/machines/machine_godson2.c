/*
 *  Copyright (C) 2005-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUS_PCI_C
#include "bus_isa.h"
#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "machine.h"
#include "machine_interrupts.h"
#include "memory.h"
#include "misc.h"
#include "it8172.h"
#include "it8712.h"
#include "bonito.h"
#include "irq.h"

extern NBINIT(it);
extern NBINIT(bonito);
extern SBINIT(vt82c686b);

MACHINE_SETUP(godson2)
{
	struct pci_data *pci_data;
	char tmpstr[1000];
	char tmps[50];
	uint64_t env, tmpptr;
	switch (machine->machine_subtype) {
	case MACHINE_GODSON2_ITE:
		cpu->byte_order = EMUL_LITTLE_ENDIAN;
		machine->machine_name = "GODSON2-NC (Godson-2, little endian)";
		machine->stable = 1;

		/* to do ++ interrupter */
		/* to do -- */
		nbinit_it(machine, 2); //plj
		break;
	case MACHINE_GODSON2_BONITO:
		cpu->byte_order = EMUL_LITTLE_ENDIAN;
		machine->machine_name = "GODSON2E-LONGMENG (longmeng, 64bit wide, little endian)";
		machine->stable = 1;
		/* Add Bonito North bridge  */
		/* int0 hardware line */
		pci_data = nbinit_bonito(machine, 2); 
		/* Add VIA 686B South bridge to Bonito */
		/* tag = bus << 16 | dev << 11. (bus,dev)=(0,5) */
		sbinit_vt82c686b(machine, pci_data, 0x2800);

		snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=%d addr=0x%x"
			" in_use=%i", NB_IRQ_BASE + BONITOINT_UART - BONITOINT_BONITO_BASE, 
			BONITO_DEV_BASE + 0x3f8, machine->use_x11 ? 0 : 1);
		machine->main_console_handle = (size_t)device_add(machine, tmpstr);

		/* Ugly, FIXME!! */
		snprintf(tmpstr, sizeof(tmpstr), "nodev addr=0x%x", BONITO_PCIIO_BASE + 0x170);
		device_add(machine, tmpstr);
		snprintf(tmpstr, sizeof(tmpstr), "nodev addr=0x%x",	BONITO_PCIIO_BASE + 0x1e0);
		device_add(machine, tmpstr);
		snprintf(tmpstr, sizeof(tmpstr), "nodev addr=0x%x",	BONITO_PCIIO_BASE + 0x160);
		device_add(machine, tmpstr);


#if 1 
		bus_pci_add(machine, pci_data, machine->memory, 0, 6, 0, "ati_radeon_7000m");
		bus_pci_add(machine, pci_data, machine->memory, 0, 7, 0, "rtl8139");
		/* 8259 int3 hardware line */
#endif
		machine->isa_pic_data.native_irq = 5;
		bus_isa_init(machine, BUS_ISA_IDE0, BONITO_PCIIO_BASE, 0x00000000, ISA_IRQ_BASE, REASSERT_IRQ);
//		bus_isa_init(machine, 0, BONITO_PCIIO_BASE, 0x00000000, ISA_IRQ_BASE, REASSERT_IRQ);
		break;
	default:fatal("Unimplemented GODSON2 model.\n");
		exit(1);
	}

	/*  a0 = argc  */
	cpu->cd.mips.gpr[MIPS_GPR_A0] = 2;

	/*  a1 = argv  */
	cpu->cd.mips.gpr[MIPS_GPR_A1] = (int32_t)0x9fc01000;
	store_32bit_word(cpu, (int32_t)0x9fc01000, 0x9fc01040);
	store_32bit_word(cpu, (int32_t)0x9fc01004, 0x9fc01200);
	store_32bit_word(cpu, (int32_t)0x9fc01008, 0);

	machine->bootstr = strdup(machine->boot_kernel_filename);
	machine->bootarg = strdup(machine->boot_string_argument);
	store_string(cpu, (int32_t)0x9fc01040, machine->bootstr);
	store_string(cpu, (int32_t)0x9fc01200, machine->bootarg);

	/*  a2 = (linux_env_var *)envp  */
	cpu->cd.mips.gpr[MIPS_GPR_A2] = (int32_t)0x9fc01800;

	env = cpu->cd.mips.gpr[MIPS_GPR_A2];
	tmpptr = 0x9fc01c00ULL;

	snprintf(tmps, sizeof(tmps), "%d", machine->physical_ram_in_mb);
	add_environment_string_dual(cpu, &env, &tmpptr, "memsize", tmps);

	snprintf(tmps, sizeof(tmps), "%d", 10000000);
	add_environment_string_dual(cpu, &env, &tmpptr, "cpuclock", tmps);

	add_environment_string_dual(cpu, &env, &tmpptr, "linux", "2.6.18");

	/*  End of env:  */
	tmpptr = 0;
	add_environment_string_dual(cpu,
		    &env, &tmpptr, NULL, NULL);


	if (!machine->prom_emulation)
		return;
}


MACHINE_DEFAULT_CPU(godson2)
{
	switch (machine->machine_subtype) {
	case MACHINE_GODSON2_ITE:
		machine->cpu_name = strdup("GODSON-2");
		break;
	case MACHINE_GODSON2_BONITO:
		machine->cpu_name = strdup("GODSON-2");
		break;
	default:fatal("Unimplemented Godson2 subtype.\n");
		exit(1);
	}
}


MACHINE_DEFAULT_RAM(godson2)
{
	switch (machine->machine_subtype) {
	case MACHINE_GODSON2_ITE:
	   	machine->physical_ram_in_mb = 128;
		break;
	case MACHINE_GODSON2_BONITO:
	   	machine->physical_ram_in_mb = 256;
		break;
	default:fatal("Unimplemented Godson2 subtype.\n");
		exit(1);
	}
}


MACHINE_REGISTER(godson2)
{
	MR_DEFAULT(godson2, "Godson-2 (ict godson-2)", ARCH_MIPS,
	    MACHINE_GODSON2);
	machine_entry_add_alias(me, "godson2");
	machine_entry_add_subtype(me, "ITE", MACHINE_GODSON2_ITE, "ite", NULL);
	machine_entry_add_subtype(me, "BONITO", MACHINE_GODSON2_BONITO, "bonito", NULL);
	me->set_default_ram = machine_default_ram_godson2;
}

