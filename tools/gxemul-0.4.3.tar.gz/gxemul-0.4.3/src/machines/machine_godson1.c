/*
 *  Copyright (C) 2005-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bus_isa.h"
#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "machine.h"
#include "machine_interrupts.h"
#include "memory.h"
#include "misc.h"

#include "godson1_soc.h"
#include "it8172.h"

extern void dev_fcr_soc_init(struct machine *machine, struct memory *memory);
extern NBINIT(it);

MACHINE_SETUP(godson1)
{
//	char tmpstr[1000];
	uint64_t env, tmpptr;
	char tmps[50];
    	struct pci_data *pci_data;

	switch (machine->machine_subtype) {
	case MACHINE_GODSON1_FCR_SOC:
		cpu->byte_order = EMUL_LITTLE_ENDIAN;
		machine->machine_name = "FCR SOC (Godson-1, little endian)";
		machine->stable = 1;

		dev_fcr_soc_init(machine, machine->memory);
		break;

	case MACHINE_GODSON1_ITE:
		cpu->byte_order = EMUL_LITTLE_ENDIAN;
		machine->machine_name = "GODSON1-NC (Godson-1, little endian)";
		machine->stable = 1;

		pci_data = nbinit_it(machine, 2); 
//		snprintf(tmpstr, sizeof(tmpstr), "intelflash irq=24 addr=0x%x"
//			,IT8172_FLASH_BASE) ;
//		device_add(machine, tmpstr);
	
//		bus_isa_init(machine, BUS_ISA_IDE0 | BUS_ISA_IDE1, IT8172_PCI_IO_BASE, 0x00000000, 0, 16);
		break;

	default:fatal("Unimplemented GODSON1 model.\n");
		exit(1);
	}

	/*  a0 = argc  */
	cpu->cd.mips.gpr[MIPS_GPR_A0] = 2;

	/*  a1 = argv  */
	cpu->cd.mips.gpr[MIPS_GPR_A1] = (int32_t)0x9fc01000;
	store_32bit_word(cpu, (int32_t)0x9fc01000, 0x9fc01040);
	store_32bit_word(cpu, (int32_t)0x9fc01004, 0x9fc01200);
	store_32bit_word(cpu, (int32_t)0x9fc01008, 0);

	machine->bootstr = strdup(machine->boot_kernel_filename);
	machine->bootarg = strdup(machine->boot_string_argument);
	store_string(cpu, (int32_t)0x9fc01040, machine->bootstr);
	store_string(cpu, (int32_t)0x9fc01200, machine->bootarg);

	/*  a2 = (linux_env_var *)envp  */
	cpu->cd.mips.gpr[MIPS_GPR_A2] = (int32_t)0x9fc01800;

	env = cpu->cd.mips.gpr[MIPS_GPR_A2];
	tmpptr = 0x9fc01c00ULL;

	snprintf(tmps, sizeof(tmps), "%d", machine->physical_ram_in_mb);
	add_environment_string_dual(cpu, &env, &tmpptr, "memsize", tmps);

	add_environment_string_dual(cpu, &env, &tmpptr, "linux", "2.4.18");

	/*  End of env:  */
	tmpptr = 0;
	add_environment_string_dual(cpu,
		    &env, &tmpptr, NULL, NULL);


	if (!machine->prom_emulation)
		return;
}


MACHINE_DEFAULT_CPU(godson1)
{
//    printf("machine %p\n", machine);
	switch (machine->machine_subtype) {
	case MACHINE_GODSON1_FCR_SOC:
	case MACHINE_GODSON1_ITE:
		machine->cpu_name = strdup("GODSON-1");
//		machine->cpu_name = strdup("R4000");
		break;
	default:fatal("Unimplemented Godson1 subtype.\n");
		exit(1);
	}
}


MACHINE_DEFAULT_RAM(godson1)
{
    	switch (machine->machine_subtype) {
	    case MACHINE_GODSON1_ITE:
		machine->physical_ram_in_mb = 128;
		break;
	    case MACHINE_GODSON1_FCR_SOC:
		machine->physical_ram_in_mb = 64;
		break;
	    default:
		machine->physical_ram_in_mb = 64;
		break;
	}
}


MACHINE_REGISTER(godson1)
{
	MR_DEFAULT(godson1, "Godson-1 (ict godson-1)", ARCH_MIPS,
	    MACHINE_GODSON1);
	machine_entry_add_alias(me, "godson1");
	machine_entry_add_subtype(me, "FCR SOC", MACHINE_GODSON1_FCR_SOC, "fcr-soc", NULL);
	machine_entry_add_subtype(me, "IT8172", MACHINE_GODSON1_ITE, "godson1-ite", NULL);
	me->set_default_ram = machine_default_ram_godson1;
}

