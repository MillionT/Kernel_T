/* File: godson1_soc.h
 *
 * Author: liangjin Peng
 *
 *	Common SOC relative header
 */

#ifndef __FCR_SOC__H__
#define __FCR_SOC__H__

#define FCR_SOC_IO_BASE		0x1f000000

/* FCR SOC Memory control regs */
#define FCR_SOC_SD_BASE		0x1f000000
#define REG_SD_TIMING			0x0
#define REG_SD_MOD_SIZE			0x4

/* LCD regs */
#define FCR_SOC_LCD_BASE		0x1f001000
#define REG_LCD_CTRL			0x00
#define REG_LCD_STAT			0x04
#define REG_LCD_HTIM			0x08
#define REG_LCD_VTIM			0x0c
#define REG_LCD_HVLEN			0x10
#define REG_LCD_VBARa			0x14
#define REG_LCD_VBARb			0x18
#define REG_LCD_C0XY			0x30
#define REG_LCD_C0BAR			0x34
#define REG_LCD_C0CR			0x40
#define REG_LCD_C1XY			0x70
#define REG_LCD_C1BAR			0x74
#define REG_LCD_CICR			0x80
#define REG_LCD_PCLT			0x800


/* MAC regs */
#define FCR_SOC_MAC_BASE		 0x1f002000
#define REG_MAC_MODER           	 0x00000000	     // 0x00 
#define REG_MAC_INT_SOURCE      	 0x00000004	     // 0x04
#define REG_MAC_INT_MASK        	 0x00000008	     // 0x08 
#define REG_MAC_IPGT            	 0x0000000C	     // 0x0C 
#define REG_MAC_IPGR1           	 0x00000010	     // 0x10
#define REG_MAC_IPGR2           	 0x00000014	     // 0x14
#define REG_MAC_PACKETLEN       	 0x00000018	     // 0x18
#define REG_MAC_COLLCONF        	 0x0000001C	     // 0x1C
#define REG_MAC_TX_BD_NUM       	 0x00000020	     // 0x20
#define REG_MAC_CTRLMODER       	 0x00000024	     // 0x24   
#define REG_MAC_MIIMODER        	 0x00000028	     // 0x28 
#define REG_MAC_MIICOMMAND      	 0x0000002C	     // 0x2C
#define REG_MAC_MIIADDRESS      	 0x00000030	     // 0x30    
#define REG_MAC_MIITX_DATA      	 0x00000034	     // 0x34
#define REG_MAC_MIIRX_DATA      	 0x00000038	     // 0x38
#define REG_MAC_MIISTATUS       	 0x0000003C	     // 0x3C
#define REG_MAC_ADDR0           	 0x00000040	     // 0x40
#define REG_MAC_ADDR1           	 0x00000044	     // 0x44
#define REG_MAC_HASH0           	 0x00000048	     // 0x48
#define REG_MAC_HASH1           	 0x0000004C	     // 0x4C
#define REG_MAC_TX_CTRL         	 0x00000050	     // 0x50    
#define REG_MAC_BD_BASE         	 0x00000400	     // 0x400

/* USB regs */
#define FCR_SOC_USB1_BASE		 0x1f003000
#define FCR_SOC_USB2_BASE		 0x1f003100

/* AHB BUS control regs */
#define FCR_SOC_AHB_MISC_BASE	 0x1f003200
#define FCR_SOC_AHB_LENGTH	0x2c
#define AHB_MISC_CTRL		0x00
#define AHB_CLK			33333333
/* Interrupt register */
#define REG_INT_EDGE		0x04
#define REG_INT_STEER		0x08
#define REG_INT_POL		0x0c
#define REG_INT_SET		0x10
#define REG_INT_CLR		0x14
#define REG_INT_EN		0x18
#define REG_INT_ISR		0x1c
#define FCR_SOC_INTC_BASE	FCR_SOC_AHB_MISC_BASE + REG_INT_EDGE
/* GPIO register */
#define REG_GPIO_OE19_0		0x20
#define REG_GPIO_R19_0		0x24
#define REG_GPIO_W19_0		0x28

/* SPI regs */
#define FCR_SOC_SPI_BASE		 0x1f004000
#define REG_SPCR			 0x00
#define REG_SPSR			 0x01
#define REG_SPDR			 0x02
#define REG_SPER			 0x03

/* UART regs */
#define FCR_SOC_UART0_BASE		 0x1f004080
#define FCR_SOC_UART1_BASE		 0x1f004090
#define FCR_SOC_MODEM_BASE		 0x1f0040a0

/* IC card regs */
#define FCR_SOC_IC0_BASE		 0x1f0040b0
#define FCR_SOC_IC1_BASE		 0x1f0040c0

/* APB BUS control regs */
#define FCR_SOC_APB_MISC_BASE	 0x1f004100
#define FCR_SOC_APB_LENGTH	0x44
#define REG_GPIO_OE47_20	0x00
#define REG_GPIO_OE77_48	0x08
#define REG_GPIO_R47_20		0x10
#define REG_GPIO_R77_48		0x18
#define REG_GPIO_W47_20		0x20
#define REG_GPIO_W77_48		0x28
#define REG_APB_MISC_CTL	0x40
#define APB_CLK			AHB_CLK


#define FCR_SOC_LCD_IRQ		0
#define FCR_SOC_MAC_IRQ		1
#define FCR_SOC_USB0_IRQ	2
#define FCR_SOC_USB1_IRQ	3
#define FCR_SOC_SPI_IRQ		8
#define FCR_SOC_KBD_IRQ		9
#define FCR_SOC_MOUSE_IRQ	10
#define FCR_SOC_UART0_IRQ	11
#define FCR_SOC_UART1_IRQ	12
#define FCR_SOC_MODEM_IRQ	13
#define FCR_SOC_IC0_IRQ		14
#define FCR_SOC_IC1_IRQ		15
#define FCR_SOC_GPIO_IRQ	16

#define INT_IC1		0x8000
#define INT_IC0		0x4000
#define INT_MODEM	0x2000
#define INT_UART1	0x1000
#define INT_UART0 	0x800
#define INT_MOUSE	0x400
#define INT_KBD		0x200
#define INT_SPI		0x100
#define INT_USB1	0x8
#define INT_USB0 	0x4
#define INT_MAC		0x2
#define INT_LCD		0x1

#endif /*__FCR_SOC__H__*/
