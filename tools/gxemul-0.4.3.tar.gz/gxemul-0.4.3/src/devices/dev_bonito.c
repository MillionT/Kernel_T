
/*
 *  Copyright (C) 2003-2006  Anders Gavare.  All rights reserved.
 *  Athor: Pengliangjin. ict.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "bus_pci.h"
#include "devices.h"
#include "device.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"

#include "bonito.h"
#include "irq.h"

#define	TICK_SHIFT	14

struct bonito_data {
	int	irqnr;
	int	pciirq;
	int 	cur_bus;
	int	cur_dev;
	int	cur_func;

	/* Based at 1fe00000, bonito pci configuration space */
	struct pcicnf {
	    uint32_t pcidid;		/* 0 */
	    uint32_t pcicmd;		/* 4 */
	    uint32_t pciclass;		/* 8 */
	    uint32_t pciltimer;		/* c */
	    uint32_t pcibase0;		/* 10 */
	    uint32_t pcibase1;		/* 14 */
	    uint32_t pcibase2;		/* 18 */
	    uint32_t resv[5];		/* 1c~2c */
	    uint32_t pciexprbase;	/* 30 */
	    uint32_t resv1[2];		/* 34,38 */
	    uint32_t pciint;		/* 3c */
	}pcicnf;
	/* Based at 1fe00100, bonito local register space */
	struct bonlocal {
	    uint32_t bonponcfg;		/* 0 */
	    uint32_t bongencfg;		/* 4 */
	    uint32_t iodevcfg;		/* 8 */
	    uint32_t sdcfg;		/* c */
	    uint32_t pcimap;		/* 10 */
	    uint32_t pcimembasecfg;	/* 14 */
	    uint32_t pcimap_cfg;	/* 18 */
	    uint32_t gpiodata;		/* 1c */
	    uint32_t gpioie;		/* 20 */
	    uint32_t intedge;		/* 24 */
	    uint32_t intsteer;		/* 28 */
	    uint32_t intpol;		/* 2c */
	    uint32_t intenset;		/* 30 */
	    uint32_t intenclr;		/* 34 */
	    uint32_t inten;		/* 38 */
	    uint32_t intisr;		/* 3c */
	    uint32_t pcimail0;		/* 40 */
	    uint32_t pcimail1;		/* 44 */
	    uint32_t pcimail2;		/* 48 */
	    uint32_t pcimail3;		/* 4c */
	    uint32_t pcicachectrl;	/* 50 */
	    uint32_t pcicachetag;	/* 54 */
	    uint32_t pcibadaddr;	/* 5c */
	    uint32_t timercfg;		/* 60 */
	}bonlocal;
	/* Based at 1fe00200, bonito IDE DMA */
	struct bonldma {
	    uint32_t ldmactrl;
	    uint32_t ldmastat;
	    uint32_t ldmaaddr;
	    uint32_t ldmago;
	}bonldma;
	/* Based at 1fe00300, bonito Copier */
	struct boncop {
	    uint32_t copctrl;
	    uint32_t copstat;
	    uint32_t coppaddr;
	    uint32_t copgo;
	}boncop;

	struct pci_data *pci_data;
};


/*
 *  Bonito (MIPS) Interrupt Controller.
 *
 *  (Used by the GODSON1/GODSON2 machine.)
 */
void bonito_interrupt(struct machine *m, struct cpu *cpu, int irq_nr, int assrt)
{
	struct bonito_data *d = (struct bonito_data *)m->md_int.priv; 

	if (m->isa_pic_data.pic1) {
		if (irq_nr >= ISA_IRQ_BASE && irq_nr <= ISA_IRQ_END || irq_nr == REASSERT_IRQ) {
			debug("[ bonito_interrupt: irq=%d, assrt=%d ]\n", irq_nr, assrt);
			if (irq_nr == REASSERT_IRQ)
				debug("[ bonito_interrupt: 8259 interrupt %s ]\n", assrt?"INT":"ACK");
			isa8_interrupt(m, cpu, irq_nr, assrt);
			return ;
		}
	}

	if (irq_nr >= NB_IRQ_BASE && irq_nr <= NB_IRQ_BASE+31)
		irq_nr -= NB_IRQ_BASE;
	else
		fatal("[ %s: Unknown irq %d ]\n", __FUNCTION__, irq_nr);

//	printf("[ 1 bonito_interrupt: irq=%d ]\n", irq_nr);

	/* interrupt from subdevices */
	if (assrt) {
		if (d->bonlocal.inten & (1<<irq_nr)) {
			d->bonlocal.intisr |= (1<<irq_nr);
			cpu_interrupt(cpu, d->irqnr);
		}
	}
	else {
		d->bonlocal.intisr &= ~(1<<irq_nr);
		if ((d->bonlocal.intisr == 0) && 
				(d->bonlocal.inten & (1<<irq_nr))) {
			cpu_interrupt_ack(cpu, d->irqnr);
		}
	}
}



/*******************************************/
/*	Bonito System config register	   */
/*	controller			   */	
/*******************************************/
/*
 *  dev_bonito_tick():
 */
void dev_bonito_tick(struct cpu *cpu, void *extra)
{
#if 0
	struct it_data *it_data = extra;

	cpu_interrupt(cpu, it_data->irqnr);
#endif
}

/*
 * dev_bonconf_access()
 * This is only useful to PCI/Bonito access, and is
 * no useful for CPU accessing Bonito. So I reserved 
 * this access that may be utilized in the future.
 */
DEVICE_ACCESS(bonconf)
{
    uint64_t idata = 0, odata = 0;
    int bus, dev, func, reg;
    struct bonito_data *d = extra;

    if (writeflag == MEM_WRITE) {
	int offset = relative_addr/sizeof(uint32_t);
	idata = memory_readmax64(cpu, data, len);
	switch (offset) {
	    case 4:
		((uint32_t *)(&d->pcicnf))[offset] &= ~(idata & 0xffffffff);
		break;
	    default:
		break;
	}
    }
    else {
	odata = ((uint32_t *)(&d->pcicnf))[relative_addr/sizeof(uint32_t)];
	memory_writemax64(cpu, data, len, odata);
    }
    return 1;
}

/*
 * dev_bonlocal_access()
 * As discribed above, I only concern about the CPU/Local access.
 */
DEVICE_ACCESS(bonlocal)
{
	uint64_t idata = 0, odata = 0;
	struct bonito_data *d = extra;

	if (writeflag == MEM_WRITE) {
		idata = memory_readmax64(cpu, data, len);
		debug("relative_addr=%8llx, idata=%8llx, len=%d\n", relative_addr, idata, len);
		switch (relative_addr) {
			case 0x38:
			case 0x3c:
				printf("[ bonlocal: Access to non-writeable register %08llx! ]\n", relative_addr);
				break;
			case 0x30:
				d->bonlocal.intenset = (uint32_t)idata;
				d->bonlocal.inten |= d->bonlocal.intenset;
				debug("[ bonito interrupt enable register %x ]\n", d->bonlocal.inten);
				break;
			case 0x34:
				d->bonlocal.intenclr = (uint32_t)idata;
				d->bonlocal.inten &= ~(d->bonlocal.intenclr);
				debug("[ bonito interrupt disable register %x ]\n", d->bonlocal.inten);
				if (d->bonlocal.intisr == 0) {
					cpu_interrupt_ack(cpu, d->irqnr);
				}
				break;
			default:
				((uint32_t *)(&d->bonlocal))[relative_addr/sizeof(uint32_t)] = idata & 0xffffffff;
				break;
		}
	}
	else {
		odata = ((uint32_t *)(&d->bonlocal))[relative_addr/sizeof(uint32_t)];
		switch (relative_addr) {
			case 0x3c:
//				d->bonlocal.intisr = 0;
//			((uint32_t *)(&d->bonlocal))[relative_addr/sizeof(uint32_t)] = 0;
				break;
			default:
				break;
		}
		memory_writemax64(cpu, data, len, odata);
	}
	return 1;
}

/*
 * dev_bonldma_access()
 */
DEVICE_ACCESS(bonldma)
{
    uint64_t idata = 0, odata = 0;
    struct bonito_data *d = extra;

    if (writeflag == MEM_WRITE) {
	idata = memory_readmax64(cpu, data, len);
	((uint32_t *)(&d->bonldma))[relative_addr/sizeof(uint32_t)] = idata & 0xffffffff;
    }
    else {
	odata = ((uint32_t *)(&d->bonldma))[relative_addr/sizeof(uint32_t)];
	memory_writemax64(cpu, data, len, odata);
    }
    return 1;
}

/*
 * dev_boncop_access()
 */
DEVICE_ACCESS(boncop)
{
    uint64_t idata = 0, odata = 0;
    struct bonito_data *d = extra;

    if (writeflag == MEM_WRITE) {
	idata = memory_readmax64(cpu, data, len);
	((uint32_t *)(&d->boncop))[relative_addr/sizeof(uint32_t)] = idata & 0xffffffff;
    }
    else {
	odata = ((uint32_t *)(&d->boncop))[relative_addr/sizeof(uint32_t)];
	memory_writemax64(cpu, data, len, odata);
    }
    return 1;
}


/*
 * dev_bonpci_access()
 * PCI devices configration access to Bonito North bridge
 */
DEVICE_ACCESS(bonpci)
{
    uint64_t idata = 0, odata = 0;
    int bus = 0, dev = -1, func = 0, reg = 0;
    uint32_t tmp, tmp1 ,tmp2;
    struct bonito_data *d = extra;
    int found_idsel = 0;

    tmp = relative_addr & 0xfffc;
    tmp1 = ((d->bonlocal.pcimap_cfg & 0xffff) << 16) | tmp;
    if (d->bonlocal.pcimap_cfg & 0x10000) {
	tmp2 = tmp1 >> 24;
	bus = (tmp1 >> 16) & 0xff;
    }
    else {
	tmp2 = tmp1 >> 11;
    }
    if (tmp2 == 0) {
		return 1;
		fatal("[ bonpci: PCI configration cannot access without chip selects! ]\n");
	}
	tmp = tmp2;
	while (tmp2)
	{
		if (tmp2 & 0x1) {
			if (found_idsel) {
				return 1;
				fatal("[ bonpci: Multi access idsel %x! ]\n", tmp);
			}
			found_idsel = 1;
		}
		tmp2 >>= 1;
		dev++;
	}

	func = (tmp1 >> 8) & 0x7;
	reg = (tmp1) & 0xfc;

	debug("bus=%d,dev=%d,fun=%d,reg=%x\n", bus, dev, func, reg);
	d->cur_bus = bus;
	d->cur_dev = dev;
	d->cur_func = func;

	bus_pci_setaddr(cpu, d->pci_data, bus, dev, func, reg);
	if (writeflag == MEM_WRITE) {
		idata = memory_readmax64(cpu, data, len);
		bus_pci_data_access(cpu, d->pci_data, &idata, len, writeflag); // pci data
	}
	else {
		bus_pci_data_access(cpu, d->pci_data, &odata, len, writeflag); // pci data
		memory_writemax64(cpu, data, len, odata);
	}
	return 1;

}

/*
 *  dev_bonito_init():
 *
 *  Initialize a Bonito devices.  Return a pointer to the pci_data used, so that
 *  the caller may add PCI devices.  First, however, we add the bonito device
 *  itself.
 */
#if 0
struct pci_data *dev_bonito_init(struct machine *machine)
#endif
NBINIT(bonito)
{
	struct bonito_data *d;
	char tmpstr[1000];
	uint64_t pci_portbase = BONITO_PCIIO_BASE;
	uint64_t pci_membase = BONITO_PCIHI_BASE;
	int pci_irqbase = NB_IRQ_BASE;
	uint64_t isa_portbase = BONITO_PCIIO_BASE, isa_membase = 0x10000000;
	int isa_irqbase = ISA_IRQ_BASE;
	uint64_t pci_io_offset = 0, pci_mem_offset = 0;

	d = malloc(sizeof(struct bonito_data));
	if (d == NULL) {
		fprintf(stderr, "out of memory\n");
		exit(1);
	}
	memset(d, 0, sizeof(struct bonito_data));

	d->irqnr    = irq_nr;
	d->pciirq   = 0; 

	d->pci_data = bus_pci_init(machine,
			d->pciirq, pci_io_offset, pci_mem_offset,
			pci_portbase, pci_membase, pci_irqbase,
			isa_portbase, isa_membase, isa_irqbase);

	machine->md_interrupt = bonito_interrupt;
	machine->md_int.priv = d;

	machine_add_tickfunction(machine, dev_bonito_tick, d, TICK_SHIFT, 0.0);

	memory_device_register(machine->memory, "bonconf", BONITO_REG_BASE + BONITO_CONFIGBASE,
			BONCONF_LENGTH, dev_bonconf_access, d,
			DM_DEFAULT, NULL);
	memory_device_register(machine->memory, "bonlocal", BONITO_REG_BASE + BONITO_BONITOBASE,
			BONLOCAL_LENGTH, dev_bonlocal_access, d,
			DM_DEFAULT, NULL);
	memory_device_register(machine->memory, "bonldma", BONITO_REG_BASE + BONITO_LDMABASE,
			BONLDMA_LENGTH, dev_bonldma_access, d, 
			DM_DEFAULT, NULL);
	memory_device_register(machine->memory, "boncop", BONITO_REG_BASE + BONITO_COPBASE,
			BONCOP_LENGTH, dev_boncop_access, d,
			DM_DEFAULT, NULL);
	memory_device_register(machine->memory, "bonpci", BONITO_PCICFG_BASE,
			BONITO_PCICFG_SIZE, dev_bonpci_access, d,
			DM_DEFAULT, NULL);

	return d->pci_data;
}

