/*
 *  Copyright (C) 2003-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "bus_pci.h"
#include "devices.h"
#include "device.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"

#include "mc146818reg.h"
#include "it8172.h"
#include "it8172_int.h"
#include "irq.h"


#define	to_bcd(x)	( ((x)/10) * 16 + ((x)%10) )
#define	from_bcd(x)	( ((x)>>4) * 10 + ((x)&15) )
#define to_AM_PM(x)	(d->use_bcd?from_bcd(x)>13?to_bcd(from_bcd(x)+80):to_bcd(x):x)


#define	TICK_SHIFT	14
#define BANK1_BASE	0x80
#define ALARM2_BASE	0x100
#define CENTURY_BASE	0x107


/* Bank0 registers plus Bank1 registers plus Alarm registers */
#define	N_REGISTERS	264
struct it_rtc_data {
    int	addrmult;
    int	access_style;

    int	reg[N_REGISTERS];
    int	index_bank0;
    int	if_index_bank0;
    int	index_bank1;
    int	if_index_bank1;
    int	index_alarm2;
    int	if_index_alarm2;

    int	use_bcd;
    int hour_12mode;

    int	timebase_hz;
    int	interrupt_hz;
    int	irq_nr;

    int	previous_second;
    int	n_seconds_elapsed;
    int	uip_threshold;

    int	interrupt_every_x_cycles;
    int	cycles_left_until_interrupt;
};

struct it_intc_data {
	/* Interrupt controller register */
	unsigned short lb_req;      
	unsigned short lb_mask;
	unsigned short lb_trigger;
	unsigned short lb_level;
	unsigned short lpc_req;     
	unsigned short lpc_mask;
	unsigned short lpc_trigger;
	unsigned short lpc_level;
	unsigned short pci_req;     
	unsigned short pci_mask;
	unsigned short pci_trigger;
	unsigned short pci_level;
	unsigned short nmi_req;     
	unsigned short nmi_mask;
	unsigned short nmi_trigger;
	unsigned short nmi_level;
	unsigned short nmi_redir;   
	unsigned short intstatus;   

	int irqnr;
};

struct it_data {
	int	irqnr;
	int	pciirq;
	int 	cur_bus;
	int	cur_dev;
	int	cur_func;

	struct pci_data *pci_data;
};


/**********************************************/
/*	IT8172 RTC Controller		      */
/**********************************************/

/*
 *  recalc_interrupt_cycle():
 *
 *  If automatic_clock_adjustment is turned on, then emulated_hz is modified
 *  dynamically.  We have to recalculate how often interrupts are to be
 *  triggered.
 */
static void recalc_interrupt_cycle(struct cpu *cpu, struct it_rtc_data *d)
{
    int64_t emulated_hz = cpu->machine->emulated_hz;
    if (d->interrupt_hz > 0)
	d->interrupt_every_x_cycles =
	    emulated_hz / d->interrupt_hz;
    else
	d->interrupt_every_x_cycles = 0;
}

/*
 *  it_rtc_update_time():
 *
 *  This function updates the it_rtc registers by reading
 *  the host's clock.
 */
static void it_rtc_update_time(struct it_rtc_data *d)
{
    struct tm *tmp;
    time_t timet;

    timet = time(NULL);
    tmp = gmtime(&timet);

    d->reg[MC_SEC]   = tmp->tm_sec;
    d->reg[MC_MIN]   = tmp->tm_min;
    d->reg[MC_HOUR]  = tmp->tm_hour;
    d->reg[MC_DOW]   = tmp->tm_wday + 1;
    d->reg[MC_DOM]   = tmp->tm_mday;
    d->reg[MC_MONTH] = tmp->tm_mon + 1;
    d->reg[MC_YEAR]  = tmp->tm_year;

    /*
     *  Special hacks for emulating the behaviour of various machines:
     */
    if (d->use_bcd) {
	d->reg[MC_SEC]   = to_bcd(d->reg[MC_SEC]);
	d->reg[MC_MIN]   = to_bcd(d->reg[MC_MIN]);
//	d->reg[MC_HOUR]  = to_bcd(d->reg[MC_HOUR]);
	d->reg[MC_DOW]   = to_bcd(d->reg[MC_DOW]);
	d->reg[MC_DOM]   = to_bcd(d->reg[MC_DOM]);
	d->reg[MC_MONTH] = to_bcd(d->reg[MC_MONTH]);
	d->reg[MC_YEAR]  = to_bcd(d->reg[MC_YEAR]);
    }
    d->reg[MC_HOUR] = to_AM_PM(d->reg[MC_HOUR]);
}


/*
 *  dev_it_rtc_access():
 *
 *  TODO: This access function only handles 8-bit accesses!
 */
DEVICE_ACCESS(it_rtc)
{
    struct tm *tmp;
    time_t timet;
    struct it_rtc_data *d = extra;
    size_t i;

    relative_addr /= d->addrmult; //plj

#ifdef MC146818_DEBUG
    if (writeflag == MEM_WRITE) {
	fatal("[ it_rtc: write to addr=0x%04x (len %i): ",
		(int)relative_addr, (int)len);
	for (i=0; i<len; i++)
	    fatal("0x%02x ", data[i]);
	fatal("]\n");
    }
#endif

    debug("reg %x, context %x\n", d->index_bank0, d->reg[d->index_bank0]);
    if (d->index_bank0 == MC_REGA || d->index_bank0 == MC_REGC) {
	timet = time(NULL);
	tmp = gmtime(&timet);
	d->reg[MC_REGC] &= ~MC_REGC_UF;
	if (tmp->tm_sec == d->previous_second) {
	    d->reg[MC_REGA] &= ~MC_REGA_UIP;
	}
	else {
	    d->previous_second = tmp->tm_sec;
	    d->reg[MC_REGA] |= MC_REGA_UIP;

	    d->reg[MC_REGC] |= MC_REGC_UF;
	    d->reg[MC_REGC] |= MC_REGC_IRQF;

	    d->reg[MC_REGC] |= MC_REGC_PF;

	}
    }

    /*  RTC data is in either BCD format or binary:  */
    if (d->use_bcd)
	d->reg[MC_REGB] &= ~(1 << 2);
    else
	d->reg[MC_REGB] |= (1 << 2);

    /*  RTC date/time is always Valid:  */
    d->reg[MC_REGD] |= MC_REGD_VRT;

    if (writeflag == MEM_WRITE) {
	/*  WRITE:  */
	switch (relative_addr) {
	    case INDEX_BANK0:
		d->index_bank0 = data[0];
		d->if_index_bank0 = 1;
		break;
	    case TARGET_BANK0:
		if (d->if_index_bank0) {
		    switch (d->index_bank0) {
			case MC_SEC:
			case MC_ASEC:
			case MC_MIN:
			case MC_AMIN:
			case MC_HOUR:
			case MC_AHOUR:
			case MC_DOW:
			case MC_DOM:
			case MC_MONTH:
			case MC_YEAR:
			    if (d->use_bcd) {
				d->reg[d->index_bank0] = to_bcd(data[0]);
				if (d->hour_12mode)
				    d->reg[d->index_bank0] = to_AM_PM(data[0]);
			    }
			    break;
			case MC_REGA:
			    if ((data[0] & MC_REGA_DVMASK) == MC_BASE_32_KHz)
				d->timebase_hz = 32000;
			    if ((data[0] & MC_REGA_DVMASK) == MC_BASE_1_MHz)
				d->timebase_hz = 1000000;
			    if ((data[0] & MC_REGA_DVMASK) == MC_BASE_4_MHz)
				d->timebase_hz = 4000000;
			    switch (data[0] & MC_REGA_RSMASK) {
				case MC_RATE_NONE:
				    d->interrupt_hz = 0;
				    break;
				case MC_RATE_1:
				    if (d->timebase_hz == 32000)
					d->interrupt_hz = 256;
				    else
					d->interrupt_hz = 32768;
				    break;
				case MC_RATE_2:
				    if (d->timebase_hz == 32000)
					d->interrupt_hz = 128;
				    else
					d->interrupt_hz = 16384;
				    break;
				case MC_RATE_8192_Hz:	d->interrupt_hz = 8192;	break;
				case MC_RATE_4096_Hz:	d->interrupt_hz = 4096;	break;
				case MC_RATE_2048_Hz:	d->interrupt_hz = 2048;	break;
				case MC_RATE_1024_Hz:	d->interrupt_hz = 1024;	break;
				case MC_RATE_512_Hz:	d->interrupt_hz = 512;	break;
				case MC_RATE_256_Hz:	d->interrupt_hz = 256;	break;
				case MC_RATE_128_Hz:	d->interrupt_hz = 128;	break;
				case MC_RATE_64_Hz:	d->interrupt_hz = 64;	break;
				case MC_RATE_32_Hz:	d->interrupt_hz = 32;	break;
				case MC_RATE_16_Hz:	d->interrupt_hz = 16;	break;
				case MC_RATE_8_Hz:	d->interrupt_hz = 8;	break;
				case MC_RATE_4_Hz:	d->interrupt_hz = 4;	break;
				case MC_RATE_2_Hz:	d->interrupt_hz = 2;	break;
				default:/*  debug("[ it_rtc: unimplemented "
					    "MC_REGA RS: %i ]\n",
					    data[0] & MC_REGA_RSMASK);  */
							;
			    }

			    recalc_interrupt_cycle(cpu, d);

			    d->cycles_left_until_interrupt =
				d->interrupt_every_x_cycles;

			    d->reg[MC_REGA] =
				data[0] & (MC_REGA_RSMASK | MC_REGA_DVMASK);

			    debug("[ rtc set to interrupt every %i:th cycle ]\n",
				    d->interrupt_every_x_cycles);
			    break;
			case MC_REGB:
			    if (((data[0] ^ d->reg[MC_REGB]) & MC_REGB_PIE))
				d->cycles_left_until_interrupt =
				    d->interrupt_every_x_cycles;
			    if (data[0] & MC_REGB_24HR)
				d->hour_12mode = 0;
			    else
				d->hour_12mode = 1;
			    if (data[0] & MC_REGB_BINARY)
				d->use_bcd = 1;
			    else
				d->use_bcd = 0;
			    d->reg[MC_REGB] = data[0];
			    if (!(data[0] & MC_REGB_PIE)) {
				cpu_interrupt_ack(cpu, d->irq_nr);
				/*  d->cycles_left_until_interrupt =
				    d->interrupt_every_x_cycles;  */
			    }
			    /*  debug("[ it_rtc: write to MC_REGB, data[0] "
				"= 0x%02x ]\n", data[0]);  */
			    break;
			case MC_REGC:
			    d->reg[MC_REGC] = data[0];
			    debug("[ it_rtc: write to MC_REGC, data[0] = "
				    "0x%02x ]\n", data[0]);
			    break;
			default:
			    d->reg[d->index_bank0] = data[0];

			    debug("[ it_rtc: unimplemented write to "
				    "index of bank0 = %08lx: ", (long)d->index_bank0);
			    for (i=0; i<len; i++)
				debug("%02x ", data[i]);
			    debug("]\n");
		    }
		}
		d->if_index_bank0 = 0;
		break;
	    case INDEX_BANK1:
		d->index_bank1 = data[0];
		d->if_index_bank1 = 1;
		break;
	    case TARGET_BANK1:
		if (d->if_index_bank1)
		    d->reg[d->index_bank1 + BANK1_BASE] = data[0];
		d->if_index_bank1 = 0;
		break;
	    case INDEX_ALARM2:
		d->index_alarm2 = data[0];
		d->if_index_alarm2 = 1;
		break;
	    case TARGET_ALARM2:
		if (d->if_index_alarm2)
		    d->reg[d->index_alarm2 + ALARM2_BASE] = data[0];
		d->if_index_alarm2 = 0;
	    case RTC_CENTURY_REG: 
		d->reg[CENTURY_BASE] = data[0];
		break;
	}
    } else {
	/*  READ:  */
	switch (relative_addr) {
	    case INDEX_BANK0:
		data[0] = d->index_bank0;
		break;
	    case TARGET_BANK0:
		if (d->if_index_bank0)
		    data[0] = d->reg[d->index_bank0];
		d->if_index_bank0 = 0;
		if (d->reg[d->index_bank0] == MC_REGC) {
		    cpu_interrupt_ack(cpu, d->irq_nr);
		    d->reg[MC_REGC] = 0x00;
		}
		break;
	    case INDEX_BANK1:
		data[0] = d->index_bank1;
		break;
	    case TARGET_BANK1:
		if (d->if_index_bank1)
		    data[0] = d->reg[d->index_bank1 + BANK1_BASE];
		d->if_index_bank1 = 0;
		break;
	    case INDEX_ALARM2:
		data[0] = d->index_alarm2;
		break;
	    case TARGET_ALARM2:
		if (d->if_index_alarm2)
		    data[0] = d->reg[d->index_alarm2 + ALARM2_BASE];
		d->if_index_alarm2 = 0;
	    case RTC_CENTURY_REG: 
		data[0] = d->reg[CENTURY_BASE];
		break;
	}
    }

#ifdef MC146818_DEBUG
    if (writeflag == MEM_READ) {
	fatal("[ it_rtc: read from addr=0x%04x (len %i): ",
		(int)relative_addr, (int)len);
	for (i=0; i<len; i++)
	    fatal("0x%02x ", data[i]);
	fatal("]\n");
    }
#endif

    return 1;
}


/*
 *  dev_it_rtc_init():
 */
int devinit_it_rtc(struct machine *machine, uint64_t addr, int irq_nr)
{
    struct it_rtc_data *d;
    int dev_len;

    d = malloc(sizeof(struct it_rtc_data));
    if (d == NULL) {
	fprintf(stderr, "out of memory\n");
	exit(1);
    }
    memset(d, 0, sizeof(struct it_rtc_data));

    d->irq_nr = irq_nr;
    d->addrmult	= 1;
    d->use_bcd = 0;
    d->uip_threshold = 0;
    d->index_bank0 = 0;
    d->if_index_bank0 = 0;
    d->index_bank1 = 0;
    d->if_index_bank1 = 0;
    d->index_alarm2 = 0;
    d->if_index_alarm2 = 0;
    d->hour_12mode = 0;
    dev_len = 9; // ite8172 RTC

    memory_device_register(machine->memory, "it_rtc", addr,
	    dev_len * d->addrmult, dev_it_rtc_access, d,
	    DM_DEFAULT, NULL);
    it_rtc_update_time(d);
    return 1;
}


/*********************************************/
/* IT8172 Interrupt controller 		     */
/*********************************************/
/*  	
 *  	It has no interrupt but will transfer it8172's interrupts
 *  	so it should be assigned the same irqnr with it8172
 */

DEVICE_ACCESS(it_intc)
{
    uint64_t idata = 0, odata = 0;
    struct it_intc_data *d = extra;


    if (len != 2)
	fatal("[ IT INTC ACCESS : len=%i! ]\n", len);

    if (writeflag == MEM_WRITE) {
	idata = memory_readmax64(cpu, data, len);
    }
    if (writeflag == MEM_WRITE) {
	switch (relative_addr) {
	    case 0x0:
		if (idata)
		    debug("write to Local Bus interrupt request register\n");
		else
		    d->lb_req &= ~(d->lb_trigger);
		break;
	    case 0x2:
		d->lb_mask = (uint16_t)(idata & 0xffff);
		if (d->lb_mask == 0xffff)
		    d->intstatus &= ~0x1;
		break;
	    case 0x4:
		d->lb_trigger = (uint16_t)(idata & 0xffff);
		break;
	    case 0x6:
		d->lb_level = (uint16_t)(idata & 0xffff);
		break;
	    case 0x10:
		if (idata)
		    debug("write to Serial IRQ interrupt request register\n");
		else
		    d->lpc_req &= ~(d->lpc_trigger);
		break;
	    case 0x12:
		d->lpc_mask = (uint16_t)(idata & 0xffff);
		if (d->lpc_mask == 0xffff)
		    d->intstatus &= ~0x2;
		break;
	    case 0x14:
		d->lpc_trigger = (uint16_t)(idata & 0xffff);
		break;
	    case 0x16:
		d->lpc_level = (uint16_t)(idata & 0xffff);
		break;
	    case 0x20:
		if (idata)
		    debug("write to PCI interrupt request register\n");
		else
		    d->pci_req &= ~(d->pci_trigger);
		break;
	    case 0x22:
		debug("write to PCI interrupt mask register idata=%x\n", idata & 0xffff);
		d->pci_mask = (uint16_t)(idata & 0xffff);
		if (d->pci_mask == 0xffff)
		    d->intstatus &= ~0x4;
		break;
	    case 0x24:
		d->pci_trigger = (uint16_t)(idata & 0xffff);
		break;
	    case 0x26:
		d->pci_level = (uint16_t)(idata & 0xffff);
		break;
	    case 0x30:
		if (idata)
		    debug("write to NMI interrupt request register\n");
		else
		    d->nmi_req &= ~(d->nmi_trigger);
		break;
	    case 0x32:
		d->nmi_mask = (uint16_t)(idata & 0xffff);
		if (d->nmi_mask == 0xffff)
		    d->intstatus &= ~0x8;
		break;
	    case 0x34:
		d->nmi_trigger = (uint16_t)(idata & 0xffff);
		break;
	    case 0x36:
		d->nmi_level = (uint16_t)(idata & 0xffff);
		break;
	    case 0x3e:
		d->nmi_redir = (uint16_t)(idata & 0xffff);
		break;
	    case 0xfe:
		d->intstatus = (uint16_t)(idata & 0xffff);
		break;
	    default:
		debug("");
	}
	if (d->intstatus == 0)
	    cpu_interrupt_ack(cpu, d->irqnr);
    }
    else {
	switch (relative_addr) {
	    case 0x0:
		odata = d->lb_req;
		break;
	    case 0x2:
		odata = d->lb_mask;
		break;
	    case 0x4:
		odata = d->lb_trigger;
		break;
	    case 0x6:
		odata = d->lb_level;
		break;
	    case 0x10:
		odata = d->lpc_req;
		break;
	    case 0x12:
		odata = d->lpc_mask;
		break;
	    case 0x14:
		odata = d->lpc_trigger;
		break;
	    case 0x16:
		odata = d->lpc_level;
		break;
	    case 0x20:
		odata = d->pci_req;
		break;
	    case 0x22:
		odata = d->pci_mask;
		break;
	    case 0x24:
		odata = d->pci_trigger;
		break;
	    case 0x26:
		odata = d->pci_level;
		break;
	    case 0x30:
		odata = d->nmi_req;
		break;
	    case 0x32:
		odata = d->nmi_mask;
		break;
	    case 0x34:
		odata = d->nmi_trigger;
		break;
	    case 0x36:
		odata = d->nmi_level;
		break;
	    case 0x3e:
		odata = d->nmi_redir;
		break;
	    case 0xfe:
		odata = d->intstatus;
		break;
	    default:
		debug("");
	}

	memory_writemax64(cpu, data, len, odata);
    }
    return 1;
}

/*
 *  IT8172 (MIPS) Interrupt Controller.
 *
 *  (Used by the GODSON1/GODSON2 machine.)
 */
void it_interrupt(struct machine *m, struct cpu *cpu, int irq_nr, int assrt)
{
	struct it_intc_data *d = (struct it_intc_data *)m->md_int.priv; 
	int int_mask = 0;

	debug("lpc_mask=%04x lb_mask=%04x pci_mask=%04x nmi_mask=%04x\n", d->lpc_mask, d->lb_mask, d->pci_mask, d->nmi_mask);

	if (irq_nr < NB_IRQ_BASE || irq_nr > NB_IRQ_BASE + 64)
		fatal("[ %s:unknown irq %d ]\n", __FUNCTION__, irq_nr);
	irq_nr -= NB_IRQ_BASE;

	/* interrupt from subdevices */
	if (assrt) {
	    int_mask = 0;
	    if (irq_nr >= IT8172_LPC_IRQ_BASE && irq_nr <= IT8172_SERIRQ_15) {
		if (!(d->lpc_mask & (1 << (irq_nr - IT8172_LPC_IRQ_BASE)))) {
		    d->intstatus |= 0x2;
		    d->lpc_req |= (1 << (irq_nr - IT8172_LPC_IRQ_BASE));
		    int_mask = 1;
		}
	    }
	    else if (irq_nr >= IT8172_LB_IRQ_BASE && irq_nr <= IT8172_IOCHK_IRQ) {
		if (!(d->lb_mask & (1 << (irq_nr - IT8172_LB_IRQ_BASE)))) {
		    d->intstatus |= 0x1;
		    d->lb_req |= (1 << (irq_nr - IT8172_LB_IRQ_BASE));
		    int_mask = 1;
		}
	    }
	    else if (irq_nr >= IT8172_PCI_DEV_IRQ_BASE && irq_nr <= IT8172_DMA_IRQ) {
		if (!(d->pci_mask & (1 << (irq_nr - IT8172_PCI_DEV_IRQ_BASE)))) {
		    d->intstatus |= 0x4;
		    d->pci_req |= (1 << (irq_nr - IT8172_PCI_DEV_IRQ_BASE));
		    int_mask = 1;
		}
	    }
	    else if (irq_nr >= IT8172_NMI_IRQ_BASE && irq_nr <= IT8172_POWER_NMI_IRQ) {
		if (!(d->nmi_mask & (1 << (irq_nr - IT8172_NMI_IRQ_BASE)))) {
		    d->intstatus |= 0x8;
		    d->nmi_req |= (1 << (irq_nr - IT8172_NMI_IRQ_BASE));
		    int_mask = 1;
		}
	    }
	    else {
		fatal("it_interrupt: bad irq %d\n", irq_nr);
	    }

	    if (int_mask)
		cpu_interrupt(cpu, d->irqnr); // triger the int0 of mips cpu
	}
	else { /* Interrupts ack from subdevices */
	    int_mask = 0;
	    if (irq_nr >= IT8172_LPC_IRQ_BASE && irq_nr <= IT8172_SERIRQ_15) {
		if (!(d->lpc_mask & (1 << (irq_nr - IT8172_LPC_IRQ_BASE)))) {
		    d->lpc_req &= ~(1 << (irq_nr - IT8172_LPC_IRQ_BASE));
		    if (d->lpc_req == 0)
			d->intstatus &= ~0x2;
		    int_mask = 1;
		} 
	    }
	    else if (irq_nr >= IT8172_LB_IRQ_BASE && irq_nr <= IT8172_IOCHK_IRQ) {
		if (!(d->lb_mask & (1 << (irq_nr - IT8172_LB_IRQ_BASE)))) {
		    d->lb_req &= ~(1 << (irq_nr - IT8172_LB_IRQ_BASE));
		    if (d->lb_req == 0)
			d->intstatus &= ~0x1;
		    int_mask = 1;
		}
	    }
	    else if (irq_nr >= IT8172_PCI_DEV_IRQ_BASE && irq_nr <= IT8172_DMA_IRQ) {
		if (!(d->pci_mask & (1 << (irq_nr - IT8172_PCI_DEV_IRQ_BASE)))) {
		    d->pci_req &=~(1 << (irq_nr - IT8172_PCI_DEV_IRQ_BASE));
		    if (d->pci_req == 0)
			d->intstatus &= ~0x4;
		    int_mask = 1;
		}
	    }
	    else if (irq_nr >= IT8172_NMI_IRQ_BASE && irq_nr <= IT8172_POWER_NMI_IRQ) {
		if (!(d->nmi_mask & (1 << (irq_nr - IT8172_NMI_IRQ_BASE)))) {
		    d->nmi_req &= ~(1 << (irq_nr - IT8172_NMI_IRQ_BASE));
		    if (d->nmi_req == 0)
			d->intstatus &= ~0x8;
		    int_mask = 1;
		}
	    }
	    else {
		fatal("it_interrupt: bad irq %d\n", irq_nr);
	    }

	    /* No pending interrupts, we should send ack to cpu */
//	    if (d->intstatus == 0 && int_mask)
	    if (d->intstatus == 0)
		cpu_interrupt_ack(cpu, d->irqnr); // triger the int0 of mips cpu
	}
}


int devinit_it_intc(struct machine *machine, uint64_t addr, int irq_nr)
{
    struct it_intc_data *d;

    d = malloc(sizeof(struct it_rtc_data));
    if (d == NULL) {
	fprintf(stderr, "out of memory\n");
	exit(1);
    }
    memset(d, 0, sizeof(struct it_rtc_data));
    /* set default Interrupt register value */
    d->lb_mask  = 0xffff;
    d->lpc_mask = 0xffff;
    d->pci_mask = 0xffff;
    d->nmi_mask = 0xffff;
    d->lb_trigger  = 0x0801;
    d->lpc_trigger = 0xfffb;
    d->pci_trigger = 0x0030;
    d->nmi_trigger = 0x002b;
    d->lb_level = 0xf7ff;
    d->lpc_level = 0x0004;
    d->pci_level = 0x4036;
    d->nmi_level = 0xffec;
    d->nmi_redir = 0x0080;
    d->intstatus = 0x0000;
    d->irqnr = irq_nr;

    /* Interrupt controller */
    /* Initialise interrupt private data */
    machine->md_interrupt = it_interrupt;
    machine->md_int.priv = d;

    memory_device_register(machine->memory, "it_intc", addr,
	    IT_INTC_LENGTH , dev_it_intc_access, d,
	    DM_DEFAULT, NULL);
    return 1;
}


/*******************************************/
/*	IT8172 System config register	   */
/*	controller			   */	
/*******************************************/
/*
 *  dev_it_access():
 */
DEVICE_ACCESS(it_pci)
{
    uint64_t idata = 0, odata = 0;
    int bus, dev, func, reg;
    size_t i;
    struct it_data *d = extra;


    if (relative_addr >= 0x0000 && relative_addr < 0x1000)
	debug("Access system configuration registers\n");
    else if (relative_addr >= 0x1000 && relative_addr < 0x2000)
	debug("Access SDRAM Control registers\n");
    else if (relative_addr >= 0x2000 && relative_addr < 0x3000)
	debug("Access Flash/Rom Control registers\n");
    else if ((relative_addr >= 0x3000 && relative_addr < 0x4000) ||
	    (relative_addr >= 0x5000))
	fatal("Access undefined address space\n");
    else {
	debug("Access PCI Configuration Registers\n");
    }

    if (writeflag == MEM_WRITE) {
	idata = memory_readmax64(cpu, data, len);
	if (relative_addr == 0x4000) {
	    bus_pci_decompose_1(idata, &bus, &dev, &func, &reg);
	    if (dev*8+func > IT_PCI_MAX_NUMBER) {
		debug("Exceed the max number of PCI device function, ignore\n");
		return 1;
	    }
	    d->cur_bus = bus;
	    d->cur_dev = dev;
	    d->cur_func = func;
	    bus_pci_setaddr(cpu, d->pci_data, bus, dev, func, reg); // pci addr
	} else if (relative_addr == 0x4004) {
	    bus = d->cur_bus;
	    dev = d->cur_dev;
	    func = d->cur_func;
	    bus_pci_data_access(cpu, d->pci_data, &idata, len, writeflag); // pci data
	}
	debug("[ it: write to addr 0x%x:", (int)relative_addr);
	for (i=0; i<len; i++)
	    debug(" %02x", data[i]);
	debug(" ]\n");
    } else {
	if (relative_addr == 0x4004) {
	    bus = d->cur_bus;
	    dev = d->cur_dev;
	    func = d->cur_func;
	    bus_pci_data_access(cpu, d->pci_data, &odata, len, writeflag); // pci data
	}
	memory_writemax64(cpu, data, len, odata);
	debug("[ it: read from addr 0x%x, get %x]\n",
		(int)relative_addr, odata);
    }
    return 1;
}


/*
 *  dev_it_init():
 *
 *  Initialize a ITE device.  Return a pointer to the pci_data used, so that
 *  the caller may add PCI devices.  First, however, we add the ITE device
 *  itself.
 */
NBINIT(it)
{
    struct it_data *d;
    uint64_t pci_portbase = 0x14016000;
    uint64_t pci_membase = 14010000;
    int pci_irqbase = 32;
    uint64_t isa_portbase = 0, isa_membase = 0;
    int isa_irqbase = 0;
    uint64_t pci_io_offset = 0, pci_mem_offset = 0;
    char *it_name[IT_PCI_SELF_NUMBER];
    char tmpstr[1000];
    int i,j;
    
    d = malloc(sizeof(struct it_data));
    if (d == NULL) {
	fprintf(stderr, "out of memory\n");
	exit(1);
    }
    memset(d, 0, sizeof(struct it_data));

    d->irqnr    = irq_nr;
    d->pciirq   = 8; //plj

    it_name[0] = strdup("it_cpu_to_pci_bridge");
    it_name[1] = strdup("it_audio_controller");
    it_name[2] = strdup("it_dma_controller");
    it_name[3] = strdup("it_chain_dma_controller");
    it_name[4] = strdup("it_usb_host");
    it_name[5] = strdup("it_pci_to_internal_bridge");
    it_name[6] = strdup("it_ide_controller");
    it_name[7] = strdup("it_68k_controller");


    d->pci_data = bus_pci_init(machine, d->pciirq, pci_io_offset, 
	    pci_mem_offset, pci_portbase, pci_membase, pci_irqbase,
	    isa_portbase, isa_membase, isa_irqbase);
    /*
     *  pchb0 at pci0 dev 0 function 0: ITE-8172G
     *  System Controller, rev 2
     *  In fact, ITE-8172G have 8 pci controllers or bridges, we use default value
     */
    /* bus 0 device 1 function 4. PCI/internal Bus bridge */
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 0, 0, it_name[0]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 0, it_name[1]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 1, it_name[2]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 2, it_name[3]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 3, it_name[4]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 4, it_name[5]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 5, it_name[6]); 
    bus_pci_add(machine, d->pci_data, machine->memory, 0, 1, 6, it_name[7]); 
    
    memory_device_register(machine->memory, "it_pci", IT8172_BASE, IT8172_LENGTH,  
	    dev_it_pci_access, d, DM_DEFAULT, NULL);

    snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=%d addr=0x%x"
	    " in_use=%i", NB_IRQ_BASE + IT8172_UART_IRQ,
		IT8172_PCI_IO_BASE + IT_UART_BASE, machine->use_x11 ? 0 : 1);
    machine->main_console_handle = (size_t)device_add(machine, tmpstr);

    devinit_it_rtc(machine, IT8172_PCI_IO_BASE + IT_RTC_BASE, NB_IRQ_BASE + 26);
    devinit_it_intc(machine, IT8172_PCI_IO_BASE + IT_INTC_BASE, d->irqnr);

//    memory_device_register(machine->memory, "it_flash", IT8172_FLASH_BASE, IT8172_FLASH_LENGTH,
//	    dev_it_flash_access, d, DM_DEFAULT, NULL);
    
    return d->pci_data;
}

