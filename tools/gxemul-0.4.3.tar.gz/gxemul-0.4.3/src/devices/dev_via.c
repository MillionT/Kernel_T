#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "bus_pci.h"
#include "devices.h"
#include "device.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"


SBINIT(vt82c686b)
{
    struct vt_data *d;
    int bus, dev, fun, reg;

    bus_pci_decompose_1(tag, &bus, &dev, &fun, &reg);
//    printf("tag=%x, bus=%d,dev=%d,fun=%d,reg=%d\n", tag, bus, dev, fun, reg);
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 0, "via_pci_to_isa_bridge");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 1, "via_ide_controller");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 2, "via_usb0_controller");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 3, "via_usb1_controller");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 4, "via_power_management");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 5, "via_ac97_codecs");
    bus_pci_add(machine, pci_data, machine->memory, bus, dev, 6, "via_mc97_codecs");

    return 1;
}
