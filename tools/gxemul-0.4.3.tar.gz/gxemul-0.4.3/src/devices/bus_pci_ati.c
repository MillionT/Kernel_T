/*
 *  Copyright (C) 2004-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 *
 *  $Id: bus_pci_ati.c,v 1.6 2006/06/22 08:21:01 cpu Exp $
 *  
 *  Generic PCI bus framework. This is not a normal "device", but is used by
 *  individual PCI controllers and devices.
 *
 *
 *  TODO:
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUS_PCI_C

#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "diskimage.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"



/*
 *  ATI graphics cards
 */


#define	PCI_VENDOR_ATI			0x1002
#if 0
#define	PCI_PRODUCT_ATI_RADEON_9200_2	0x5962

PCIINIT(ati_radeon_9200_2)
{
	uint64_t port, memaddr;

	PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ATI,
	    PCI_PRODUCT_ATI_RADEON_9200_2));

	/*  TODO: other subclass?  */
	PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_DISPLAY,
	    PCI_SUBCLASS_DISPLAY_VGA, 0) + 0x03);

	/*  TODO  */
	allocate_device_space(pd, 0x1000, 0x400000, &port, &memaddr);
}
#endif

PCIINIT(ati_radeon_7000m)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ATI, 0x7971));

	PCI_SET_DATA(PCI_CLASS_REG,
	    PCI_CLASS_CODE(PCI_CLASS_DISPLAY,
	    PCI_SUBCLASS_DISPLAY_VGA, 0) + 0x01);

	PCI_SET_DATA(0x10, 0x0);
    PCI_SET_DATA_SIZE(0x10, 0xfe000000);
    PCI_SET_DATA_SIZE(0x14, 0xffffff01);
    PCI_SET_DATA_SIZE(0x18, 0xffff0000);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_DISPLAY,
			    PCI_SUBCLASS_DISPLAY_VGA, 0) + 0x03);
    PCI_SET_DATA(PCI_MAPREG_ROM, 0x0);
    PCI_SET_DATA_SIZE(PCI_MAPREG_ROM, 0xfffe0000);

	{
		dev_vga_init(machine, mem, pd->pcibus->isa_membase + 0xa0000,
			pd->pcibus->pci_portbase + 0x3c0, machine->machine_name);
#if 0
		dev_id *dev_id, *p;
		dev_id = dev_vga_init(machine, mem, pd->pcibus->isa_membase + 0xa0000,
			pd->pcibus->pci_portbase + 0x3c0, machine->machine_name);
		for (p = dev_id; p->id != -1; p++)
		{
			if (p->tag == VIDEOMEM)
			{
				p->idx = 0x30;
			}
			else if (p->tag == VGACTRL)
			{
				p->idx = 0x10;
			}
		}
		pd->dev_id = dev_id;
#endif
	}
}
