
/*  $Id: autodev_middle.c,v 1.1 2005/02/22 13:23:43 debug Exp $  */

/*
 *  autodev_init():
 */
void autodev_init(void)
{
	/*  printf("autodev_init()\n");  */

	/*  autodev_middle.c ends here.  */

