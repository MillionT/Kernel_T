/*
 *  Copyright (C) 2004-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 *
 *  $Id: bus_pci_rtl.c,v 1.6 2006/06/22 08:21:01 cpu Exp $
 *  
 *  Generic PCI bus framework. This is not a normal "device", but is used by
 *  individual PCI controllers and devices.
 *
 *
 *  TODO:
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUS_PCI_C

#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "diskimage.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"

#define PCI_VENDOR_RTL	0x10ec

extern DEVICE_ACCESS(rtl8139);


struct rtl8139_cfg_extra{
	struct machine *machine;
	int dev_probed;
	void *dev_extra;
};

int rtl8139_cfg_reg_write(struct pci_device *pd, int reg, uint32_t value)
{
	uint32_t reg_value;
	int idex = -1;
	struct rtl8139_cfg_extra *d;
	struct machine *m;
	struct memory *mem;
	int size_mask;
	int is_io = 0;
	uint64_t portbase = 0, membase = 0 , base;
	void *rtl8139_extra = NULL;
	struct memory_device dev;

	d = (struct rtl8139_cfg_extra *)pd->extra;
	m = d->machine;
	mem = m->memory;

	portbase = pd->pcibus->pci_portbase;
	membase = pd->pcibus->pci_membase;

	switch (reg) {
		case PCI_MAPREG_START:
		case PCI_MAPREG_START + 4:
			if (pd->cfg_mem_size[reg] & 1)
				is_io = 1;
			if (value == 0 || value == 1) {
				fatal("Warning, BAR of pci rtl8139 is writen with wrong value , ignored!!!\n");
				break;
			}
			base = is_io?portbase:membase;
			reg_value = pd->cfg_mem[reg] | 
				pd->cfg_mem[reg+1] << 8 |
				pd->cfg_mem[reg+2] << 16 | 
				pd->cfg_mem[reg+3] << 24;
			reg_value &= 0xffffffff;

			size_mask = pd->cfg_mem_size[reg] |
				pd->cfg_mem_size[reg+1] << 8 |
				pd->cfg_mem_size[reg+2] << 16 |
				pd->cfg_mem_size[reg+3] << 24;
			size_mask &= 0xffffffff;
			if (reg_value & ~((~size_mask) | 0xf)) {
				idex = memory_device_query(mem, (uint64_t)reg_value + base, &dev);
			}
			if (idex != -1) {
				debug("Modify the old device index %d reg %x write %x\n",
						idex, reg, value);
				dev.baseaddr = base + (value & size_mask & ~0xf);
				dev.endaddr = dev.baseaddr + dev.length;
				memory_device_modify(mem, &dev, idex);
			}
			else {
				char tmpstr[200];
				debug("reg %x write %x\n", reg, value);
				PCI_SET_DATA(reg, value | (is_io?1:0));

				if (!d->dev_probed) {
					debug("Add new device\n");
					snprintf(tmpstr, sizeof(tmpstr), "rtl8139 irq=%d addr=0x%llx", 
							pd->pcibus->pci_irqbase + 10, 
							base + (value & size_mask & ~0xf));
					d->dev_extra = device_add(m, tmpstr);
					d->dev_probed = 1;
				} else {
					debug("Add new address space access\n");
					snprintf(tmpstr, sizeof(tmpstr), "rtl8139(%s)", is_io?"io":"mem");
					memory_device_register(mem, tmpstr,
							base+(value & size_mask & ~0xf),
							~(size_mask & ~0xf) + 1, 
							dev_rtl8139_access, d->dev_extra,
							DM_DEFAULT, NULL);
				}
			}
			break;
		default:
			break;
	}
	return 0;
}


PCIINIT(rtl8139)
{

    struct rtl8139_cfg_extra * extra = malloc(sizeof(struct rtl8139_cfg_extra *));
    if (extra == NULL)
	    fatal("[ %s(): not enough memory ]\n", __FUNCTION__);

    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_RTL, 0x8139));

    PCI_SET_DATA(PCI_CLASS_REG,
		    PCI_CLASS_CODE(PCI_CLASS_NETWORK,
			    PCI_SUBCLASS_NETWORK_ETHERNET, 0));

    PCI_SET_DATA(0x10, 0x1); /* IOBAR */
    PCI_SET_DATA_SIZE(0x10, 0xffffff01);
    PCI_SET_DATA(0x14, 0x0); /* MEMBAR */
    PCI_SET_DATA_SIZE(0x14, 0xffffff00);
    PCI_SET_DATA_SIZE(PCI_MAPREG_ROM, 0xffffff00);
    PCI_SET_DATA(0x34, 0x50); /* Cap_Ptr */
    PCI_SET_DATA(0x3c, 0x20200100); /* MXLAT MNGNT IPR ILR */
    PCI_SET_DATA(0x50, 0x01); /* PMC Next_Ptr PMID */
    /* Power manager donnot be supportted here */
    PCI_SET_DATA(0x60, 0x03); /* Flag VPD Address, NextPtr, VPDID */

    extra->machine = machine;
    extra->dev_probed = 0;
    extra->dev_extra = NULL;

    pd->extra = extra;
    pd->cfg_reg_write = rtl8139_cfg_reg_write;
}


