/*
 *  Copyright (C) 2003-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "bus_pci.h"
#include "devices.h"
#include "device.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"

#include "godson1_soc.h"

struct fcr_soc_data {
    	struct ahb_ctl_data {
	    int ahb_misc; 	/* 0x00 */
	    int intedge;  	/* 0x04 */
	    int intsteer; 	/* 0x08 */
	    int intpol;   	/* 0x0c */
	    int intset;   	/* 0x10 */
	    int intclr;   	/* 0x14 */
	    int inten;    	/* 0x18 */
	    int intstatus; 	/* 0x1c */
	    int gpio_oe19_0;	/* 0x20 */
	    int gpio_r19_0;	/* 0x24 */
	    int gpio_w19_0;	/* 0x28 */
	}ahb_ctl;

	struct apb_ctl_data {
	    unsigned char gpio_oe47_20;	/* 0x00 */
	    unsigned char gpio_oe77_48; /* 0x08 */
	    unsigned char gpio_r47_20;	/* 0x10 */
	    unsigned char gpio_r77_48;	/* 0x18 */
	    unsigned char gpio_w47_20;	/* 0x20 */
	    unsigned char gpio_w77_48;	/* 0x28 */
	    unsigned char reserved[2];	/* 0x30~0x38 */
	    unsigned char apb_misc;	/* 0x40 */
	}apb_ctl;

	int	irqnr;
};

DEVICE_ACCESS(fcr_soc_ahb)
{
    	struct fcr_soc_data *d = extra;
	uint64_t idata, odata;
	int off;

	if (relative_addr >= FCR_SOC_AHB_LENGTH) {
		fatal("[ FCR SoC (%s): outside register space? relative_addr="
		    "0x%llx. bad addrmult? bad device length? ]\n", __FUNCTION__,
		    (long long)relative_addr);
		return 0;
	}

	off = relative_addr/4;
	if (writeflag == MEM_WRITE) {
	    	idata = memory_readmax64(cpu, data, len);

		switch (relative_addr) {
		    case 0x00:
		    case 0x04:
		    case 0x08:
		    case 0x0c:
		    case 0x10:
		    case 0x14:
			break;
		    case 0x18:
			debug("[ %s relative_addr=%llx intstatus=%x idata=%llx]\n",
				__FUNCTION__, relative_addr, d->ahb_ctl.intstatus, idata);
			d->ahb_ctl.inten = idata;
			if (d->ahb_ctl.inten == 0) {
			    d->ahb_ctl.intstatus = 0;
			    cpu_interrupt_ack(cpu, d->irqnr); 
			}
			break;
		    case 0x1c:
		    case 0x20:
		    case 0x24:
		    case 0x28:
			break;
		    default:
			fatal("[ FCR SoC (%s): access unregister space? relative_addr="
				"0x%llx. ]\n", __FUNCTION__, (long long)relative_addr);
		}
		if (relative_addr != 0x18)
		    *((uint32_t *)(&d->ahb_ctl) + off) = idata;
	}
	else {
	    	odata = *((uint32_t *)(&d->ahb_ctl) + off);
		debug("[ %s relative_addr=%llx intstatus=%x odata=%llx inten=%x ]\n",
			__FUNCTION__, relative_addr, d->ahb_ctl.intstatus, odata, d->ahb_ctl.inten);
		memory_writemax64(cpu, data, len, odata);
	}

	return 1;
}

DEVICE_ACCESS(fcr_soc_apb)
{
    	struct fcr_soc_data *d = extra;
	uint64_t idata, odata;
	int off;

	if (len != 1)
		fatal("[ FCR SoC (%s): len=%i! ]\n", __FUNCTION__, len);

	if (relative_addr >= FCR_SOC_APB_LENGTH) {
		fatal("[ FCR SoC (%s): outside register space? relative_addr="
		    "0x%llx. bad addrmult? bad device length? ]\n", __FUNCTION__,
		    (long long)relative_addr);
		return 0;
	}

	off = relative_addr/8;
	if (writeflag == MEM_WRITE) {
	    	idata = memory_readmax64(cpu, data, len);
		switch (relative_addr) {
		    case 0x00:
		    case 0x08:
		    case 0x10:
		    case 0x18:
		    case 0x20:
		    case 0x28:
		    case 0x40:
			break;
		    default:
			fatal("[ FCR SoC (%s): access unregister space? relative_addr="
				"0x%llx. ]\n", __FUNCTION__, (long long)relative_addr);
		}
		*((uint8_t *)(&d->apb_ctl) + off) = idata;
	}
	else {
	    	odata = *((uint8_t *)(&d->apb_ctl) + off);
		memory_writemax64(cpu, data, len, odata);
	}

	return 1;
}

/*
 *  Fiscal SoC (MIPS) Interrupt Controller.
 *
 *  (Used by the GODSON1/GODSON2 machine.)
 */
void fcr_soc_interrupt(struct machine *m, struct cpu *cpu, int irq_nr, int assrt)
{
	struct fcr_soc_data *d = (struct fcr_soc_data *)m->md_int.priv; 
	int int_mask = 0;


	/* interrupt from subdevices */
	if (assrt) {
	    int_mask = 0;
	    if (d->ahb_ctl.inten  & (1 << irq_nr)) {
		d->ahb_ctl.intstatus |= (1 << irq_nr);
		int_mask = 1;
	    }
	    if (int_mask)
		cpu_interrupt(cpu, d->irqnr); 
	}
	else { /* Interrupts ack from subdevices */
	    if (d->ahb_ctl.inten  & (1 << irq_nr)) {
		d->ahb_ctl.intstatus &= ~(1 << irq_nr);
	    }
	    if (d->ahb_ctl.intstatus == 0)
		cpu_interrupt_ack(cpu, d->irqnr); 
	}
}

void dev_fcr_soc_init(struct machine *machine, struct memory *mem)
{
    	struct fcr_soc_data *d;
	char tmpstr[1000];

	d = malloc(sizeof(struct fcr_soc_data));
	if (d == NULL) {
	    fprintf(stderr, "out of memory\n");
	    exit(1);
	}

	memset(d, 0, sizeof(struct fcr_soc_data));
	d->irqnr = 2;
	d->ahb_ctl.ahb_misc = 0;
	d->ahb_ctl.intedge = 0x0000ffff;
	d->ahb_ctl.intsteer = 0;
	d->ahb_ctl.intpol = 0;
	d->ahb_ctl.intset = 0;
	d->ahb_ctl.intclr = 0;
	d->ahb_ctl.inten = 0;
	d->ahb_ctl.intstatus = 0;

	memory_device_register(mem, "fcr_soc_ahb", FCR_SOC_AHB_MISC_BASE, FCR_SOC_AHB_LENGTH,  
		dev_fcr_soc_ahb_access, d, DM_DEFAULT, NULL);
	memory_device_register(mem, "fcr_soc_apb", FCR_SOC_APB_MISC_BASE, FCR_SOC_APB_LENGTH,  
		dev_fcr_soc_apb_access, d, DM_DEFAULT, NULL);

	snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=13 addr=0x%x"
		" in_use=1 ", FCR_SOC_MODEM_BASE);
	machine->main_console_handle = (size_t)device_add(machine, tmpstr);
	snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=11 addr=0x%x"
		" in_use=0 ", FCR_SOC_UART0_BASE);
	device_add(machine, tmpstr);
	snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=12 addr=0x%x"
		" in_use=0 ", FCR_SOC_UART1_BASE);
	device_add(machine, tmpstr);
	snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=14 addr=0x%x"
		" in_use=0 ", FCR_SOC_IC0_BASE);
	device_add(machine, tmpstr);
	snprintf(tmpstr, sizeof(tmpstr), "ns16550 irq=15 addr=0x%x"
		" in_use=0 ", FCR_SOC_IC1_BASE);
	device_add(machine, tmpstr);

	machine->md_interrupt = fcr_soc_interrupt;
	machine->md_int.priv =d;
}
