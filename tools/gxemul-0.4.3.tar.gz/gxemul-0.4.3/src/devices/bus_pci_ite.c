/*
 *  Copyright (C) 2004-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 *
 *  $Id: bus_pci_ite.c,v 1.6 2006/06/22 08:21:01 cpu Exp $
 *  
 *  Generic PCI bus framework. This is not a normal "device", but is used by
 *  individual PCI controllers and devices.
 *
 *
 *  TODO:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUS_PCI_C

#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "diskimage.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"
#include "it8172_int.h"


/*
 * ITE Technology 8172G PCI controller.
 *
 *     IT8172G          Used in Godson-NC machines
 *
 *  NOTE: This works in the opposite way compared to other devices; the PCI
 *  device is added from the normal device instead of the other way around.
 */

#define PCI_VENDOR_ITE           0x1283    /* ITE Technology */
#define PCI_PRODUCT_ITE_8172  0x8172    /* EV8172 System Controller */
#define PCI_PRODUCT_ITE_AUDIO 0x0801
PCIINIT(it_cpu_to_pci_bridge)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02000006); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_BRIDGE,
		PCI_SUBCLASS_BRIDGE_HOST, 0) + 0x20);       /*  Revision 2.0  */
    PCI_SET_DATA(0x40, 0x00000002); /* PCI Memory Control */

    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
PCIINIT(it_audio_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_AUDIO));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM |
	    	PCI_STATUS_BACKTOBACK_SUPPORT | PCI_STATUS_CAPLIST_SUPPORT); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_MULTIMEDIA,
		PCI_SUBCLASS_MULTIMEDIA_AUDIO, 0) + 0xb1);       /*  Revision b1h  */
    PCI_SET_DATA(PCI_BHLC_REG, PCI_BHLC_CODE(0x00,0x00,1,0x00,0x00));
    PCI_SET_DATA(PCI_MAPREG_START, 0x14017001);
    PCI_SET_DATA_SIZE(PCI_MAPREG_START, 0xfffff801); /* PMC/NIP/CID*/
    PCI_SET_DATA(PCI_SUBSYS_ID_REG, 0x12831283); 
    PCI_SET_DATA(PCI_CAPLISTPTR_REG, 0xdc);
    PCI_SET_DATA(PCI_INTERRUPT_REG, PCI_INTERRUPT_CODE(0x28,0x04,PCI_INTERRUPT_PIN_A,0x00));
    PCI_SET_DATA(0x40, 0x00000003); /* LAC */
    PCI_SET_DATA(0x98, 0x08011283); /* Device/Vendor ID */
    PCI_SET_DATA(0x9c, 0x12831283); /* Sub-system Vendor ID */
    PCI_SET_DATA(0xdc, 0x04210001); /* PMC/NIP/CID*/

    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
PCIINIT(it_dma_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM | 
	   	PCI_COMMAND_MASTER_ENABLE | PCI_COMMAND_IO_ENABLE); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_SYSTEM,
		PCI_SUBCLASS_SYSTEM_DMA, 0x00) + 0x10);       /*  Revision 10h  */
    PCI_SET_DATA(PCI_BHLC_REG, PCI_BHLC_CODE(0x00,0x00,0,0x00,0x00));
    PCI_SET_DATA(PCI_MAPREG_START, 0x14016001);
    PCI_SET_DATA_SIZE(PCI_MAPREG_START, 0xfffff801); 
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
PCIINIT(it_chain_dma_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM | 
	   	PCI_COMMAND_MASTER_ENABLE | PCI_COMMAND_IO_ENABLE); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_SYSTEM,
		PCI_SUBCLASS_SYSTEM_DMA, 0x03) + 0x10);       /*  Revision 10h  */
    PCI_SET_DATA(PCI_BHLC_REG, PCI_BHLC_CODE(0x00,0x00,0,0x80,0x00));
    PCI_SET_DATA(PCI_MAPREG_START, 0x14016801);
    PCI_SET_DATA_SIZE(PCI_MAPREG_START, 0xfffff801);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
PCIINIT(it_usb_host)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x0006,0x0000));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x0); 
    PCI_SET_DATA(PCI_CLASS_REG, 0); 
    PCI_SET_DATA(0x34, 0x2edf);
    PCI_SET_DATA(0x44, 0x0628);
    PCI_SET_DATA(0x48, 0x0002);
    PCI_SET_DATA(0x10, 0xffffffff);
    PCI_SET_DATA(0x14, 0xffffffff);
    PCI_SET_DATA(0x18, 0xffffffff);
    PCI_SET_DATA(0x1c, 0xffffffff);
    PCI_SET_DATA(0x20, 0xffffffff);
    PCI_SET_DATA(0x24, 0xffffffff);
}
PCIINIT(it_pci_to_internal_bridge)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM | PCI_COMMAND_IO_ENABLE); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_BRIDGE,
		PCI_SUBCLASS_BRIDGE_MISC, 0) + 0x11);       /*  Revision 11h  */
    PCI_SET_DATA(0x4c, 0x3f220000);
    PCI_SET_DATA(0x50, 0x14010000); /* INTC I/O space control */
    PCI_SET_DATA(0x54, 0x14010800); /* Timer I/O space control */
    PCI_SET_DATA(0x58, 0x14011000); /* CIR0 I/O space control */
    PCI_SET_DATA(0x5c, 0x14011800); /* UART I/O space control */
    PCI_SET_DATA(0x60, 0x14012000); /* SCR0 I/O space control */
    PCI_SET_DATA(0x64, 0x14012800); /* SCR1 I/O space control */
    PCI_SET_DATA(0x68, 0x14013000); /* PP I/O space control */
    PCI_SET_DATA(0x6c, 0x14013800); /* GPIO I/O space control */
    PCI_SET_DATA(0x70, 0x14014000); /* I2C I/O space control */
    PCI_SET_DATA(0x74, 0x14014800); /* RTC I/O space control */
    PCI_SET_DATA(0x78, 0x14015000); /* CIR1 I/O space control */
    PCI_SET_DATA(0x7c, 0x14015800); /* PMU I/O space control */
    PCI_SET_DATA_SIZE(PCI_MAPREG_START, 0xfffff801);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
PCIINIT(it_ide_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM |
	   	PCI_STATUS_BACKTOBACK_SUPPORT | PCI_COMMAND_MASTER_ENABLE| PCI_COMMAND_IO_ENABLE); 
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_MASS_STORAGE,
		PCI_SUBCLASS_MASS_STORAGE_IDE, 0x85/*0x8a*/) + 0x01);       /*  Revision 1  */
    PCI_SET_DATA(PCI_MAPREG_START, 0x140179f1);
    PCI_SET_DATA(PCI_MAPREG_START + 4, 0x14017bf5);
    PCI_SET_DATA(PCI_MAPREG_START + 0x10, 0x14017801);
    PCI_SET_DATA(0x40, 0xc000);
    PCI_SET_DATA(0x44, 0xffffff00);
    PCI_SET_DATA_SIZE(PCI_MAPREG_START, 0xffffffe1); /* 0 */
    PCI_SET_DATA_SIZE(PCI_MAPREG_START + 4, 0xffffffc1); /* 0x4 */
    /* 8 & 12 reserved */
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(PCI_MAPREG_START + 0x10, 0xfffffe01); /* 0x8 */
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);

    if (diskimage_exist(machine, 0, DISKIMAGE_IDE) ||
	    diskimage_exist(machine, 1, DISKIMAGE_IDE)) {
	char tmpstr[150];
	snprintf(tmpstr, sizeof(tmpstr), "wdc addr=0x%llx irq=%i",
		(long long)(pd->pcibus->pci_portbase + 0x1800 + 0x1f0),
		pd->pcibus->pci_irqbase + IT8172_IDE_IRQ);
	device_add(machine, tmpstr);
    }
}
PCIINIT(it_68k_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(PCI_VENDOR_ITE,
		PCI_PRODUCT_ITE_8172));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, PCI_STATUS_DEVSEL_MEDIUM | PCI_COMMAND_IO_ENABLE); 
    PCI_SET_DATA(0x50, 0xf1); /* BUSAR */
    PCI_SET_DATA(0x54, 0x20); /* MBSCR */
    PCI_SET_DATA(0x5c, 0x003f0000); /* BCR/BSR/DTR */
    PCI_SET_DATA(0x60, 0x00fffffa); /* CS0BAR */
    PCI_SET_DATA(0x64, 0x0000003A); /* CS0OR */
    PCI_SET_DATA(0x68, 0x00fffffa); /* CS1BAR */
    PCI_SET_DATA(0x6c, 0x0000003A); /* CS1OR */
    PCI_SET_DATA(0x70, 0x00fffffa); /* CS2BAR */
    PCI_SET_DATA(0x74, 0x0000003A); /* CS2OR */
    PCI_SET_DATA(0x78, 0x00fffffa); /* CS3BAR */
    PCI_SET_DATA(0x7c, 0x0000003A); /* CS3OR */
    PCI_SET_DATA(0x80, 0x00fffffa); /* CS4BAR */
    PCI_SET_DATA(0x84, 0x0000003A); /* CS4OR */
    PCI_SET_DATA(0x88, 0x00fffffa); /* CS5BAR */
    PCI_SET_DATA(0x8c, 0x0000003A); /* CS5OR */
    PCI_SET_DATA(0x90, 0x00fffffa); /* CS6BAR */
    PCI_SET_DATA(0x94, 0x0000003A); /* CS6OR */
    PCI_SET_DATA(0x98, 0x00fffffa); /* CS7BAR */
    PCI_SET_DATA(0x9c, 0x0000003A); /* CS7OR */
    PCI_SET_DATA(0xa0, 0x00fffffa); /* CS8BAR */
    PCI_SET_DATA(0xa4, 0x0000003A); /* CS8OR */
    PCI_SET_DATA(0xa8, 0x00fffffa); /* CS9BAR */
    PCI_SET_DATA(0xac, 0x0000003A); /* CS9OR */
    PCI_SET_DATA(0xb0, 0x00fffffa); /* CS10BAR */
    PCI_SET_DATA(0xb4, 0x0000003A); /* CS10OR */
    PCI_SET_DATA(0xb8, 0x00fffffa); /* CS11BAR */
    PCI_SET_DATA(0xbc, 0x0000003A); /* CS11OR */
    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}

