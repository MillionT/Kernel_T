#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUS_PCI_C

#include "bus_pci.h"
#include "cpu.h"
#include "device.h"
#include "devices.h"
#include "diskimage.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"


/* 
 * VIA technology 
 * Author: Pengliangjin. ICT. 2006.06.19
 * VT82C868B	SouthBridge	Used in Godson machines
 */

PCIINIT(via_pci_to_isa_bridge)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x0686));

    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02000087);
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_BRIDGE,
		PCI_SUBCLASS_BRIDGE_ISA, 0) + 0x40);       /*  Revision 4.0  */
    PCI_SET_DATA(PCI_BHLC_REG, PCI_BHLC_CODE(0x00,0x00,1,0x00,0x00));
    PCI_SET_DATA(PCI_CAPLISTPTR_REG, 0x000000c0);
    PCI_SET_DATA(0x48, 0x00040001); /* Miscellaneous Control, Port 70/74 Access Status, 
				       IDE interrupt Routing */
    PCI_SET_DATA(0x4c, 0x03000000); /* DMA/Master Mem Access Control 1/2/3 */
    PCI_SET_DATA(0x50, 0x0000002d); /* PnP DMA Request Control,
    				       PnP Routing for LPT/FDC IRQ
				       PnP Routing for COM2/COM1 IRQ */
    PCI_SET_DATA(0x58, 0x00040400);	
    PCI_SET_DATA(0x5c, 0x04000000);	
    PCI_SET_DATA(0x74, 0x10000000); /* GPIO Control 1/2/3/4 */	
    PCI_SET_DATA(0x84, 0x00000010);	

    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}


PCIINIT(via_ide_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x0571));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02800080);
    PCI_SET_DATA(PCI_CLASS_REG, PCI_CLASS_CODE(PCI_CLASS_MASS_STORAGE,
		PCI_SUBCLASS_MASS_STORAGE_IDE, 0x8a) + 0x06);       /*  Revision 0.6  */
    PCI_SET_DATA(PCI_MAPREG_START, 0x000001f1);
    PCI_SET_DATA(PCI_MAPREG_START + 4, 0x000003f7);
    PCI_SET_DATA(PCI_MAPREG_START + 8, 0x00000171);
    PCI_SET_DATA(PCI_MAPREG_START + 0xc, 0x00000377);
    PCI_SET_DATA(PCI_MAPREG_START + 0x10, 0x0000cc01);
    PCI_SET_DATA(PCI_CAPLISTPTR_REG, 0x000000c0);
    PCI_SET_DATA(PCI_INTERRUPT_REG, 0x0000010e);	
    PCI_SET_DATA(0x40, 0x0a090208);
    PCI_SET_DATA(0x44, 0x00c00068);
    PCI_SET_DATA(0x48, 0xa8a8a8a8);
    PCI_SET_DATA(0x4c, 0x000000ff);
    PCI_SET_DATA(0x50, 0x07070707);
    PCI_SET_DATA(0x54, 0x00000004);
    PCI_SET_DATA(0x60, 0x00000200);
    PCI_SET_DATA(0x68, 0x00000200);
    PCI_SET_DATA(0xc0, 0x00020001);

    PCI_SET_DATA_SIZE(0x10, 0xffffff01);
    PCI_SET_DATA_SIZE(0x14, 0xffffff01);
    PCI_SET_DATA_SIZE(0x18, 0xffffff01);
    PCI_SET_DATA_SIZE(0x1c, 0xffffff01);
    PCI_SET_DATA_SIZE(0x20, 0xfffffffd);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);

#if 0 
    if (diskimage_exist(machine, 0, DISKIMAGE_IDE) ||
			diskimage_exist(machine, 1, DISKIMAGE_IDE)) {
		char tmpstr[150];
		snprintf(tmpstr, sizeof(tmpstr), "wdc addr=0x%llx irq=%i",
				(long long)(pd->pcibus->pci_portbase + 0x1f0),
				pd->pcibus->isa_irqbase+14);
		device_add(machine, tmpstr);
    }
	else {
		char tmpstr[150];
		snprintf(tmpstr, sizeof(tmpstr), "nodev addr=0x%llx",
				(long long)(pd->pcibus->pci_portbase + 0x1f0));
		device_add(machine, tmpstr);
	}
#endif
}

PCIINIT(via_usb0_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x3038));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x0210001a);
    PCI_SET_DATA(PCI_CLASS_REG, 0x0c030000);
    PCI_SET_DATA(0xc, 0x00001600);
    PCI_SET_DATA(0x20, 0x00000301);
    PCI_SET_DATA(0x34, 0x00000080);
    PCI_SET_DATA(0x3c, 0x00000004);
    PCI_SET_DATA(0x40, 0x00001000);
    PCI_SET_DATA(0x60, 0x00000010);
    PCI_SET_DATA(0x80, 0x00020001);
    PCI_SET_DATA(0xc0, 0x00002000);

    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffff01);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}

PCIINIT(via_usb1_controller)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x3038));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x0210001a);
    PCI_SET_DATA(PCI_CLASS_REG, 0x0c030000);
    PCI_SET_DATA(0xc, 0x00001600);
    PCI_SET_DATA(0x20, 0x00000301);
    PCI_SET_DATA(0x34, 0x00000080);
    PCI_SET_DATA(0x3c, 0x00000004);
    PCI_SET_DATA(0x40, 0x00001000);
    PCI_SET_DATA(0x60, 0x00000010);
    PCI_SET_DATA(0x80, 0x00020001);
    PCI_SET_DATA(0xc0, 0x00002000);

    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffff01);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}

PCIINIT(via_power_management)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x3057));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02900040);
    PCI_SET_DATA(0x34, 0x00000068);
    PCI_SET_DATA(0x48, 0x00000001);
    PCI_SET_DATA(0x68, 0x00020001);
    PCI_SET_DATA(0x70, 0x00000001);
    PCI_SET_DATA(0x90, 0x00000001);
    
    PCI_SET_DATA_SIZE(0x48, 0x100);
    PCI_SET_DATA_SIZE(0x70, 0x100);
    PCI_SET_DATA_SIZE(0x90, 0x100);

    PCI_SET_DATA_SIZE(0x10, 0xffffffff);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}

PCIINIT(via_ac97_codecs)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x3058));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02100050);
    PCI_SET_DATA(0x08, 0x04010000);
    PCI_SET_DATA(0x10, 0x00000001);
    PCI_SET_DATA(0x14, 0x00000001);
    PCI_SET_DATA(0x3c, 0x00000300);
    PCI_SET_DATA(0x40, 0x1c000000);

    PCI_SET_DATA_SIZE(0x10, 0xffffff01);
    PCI_SET_DATA_SIZE(0x14, 0xfffffffd);
    PCI_SET_DATA_SIZE(0x18, 0xfffffffd);
    PCI_SET_DATA_SIZE(0x1c, 0xffffff01);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}

PCIINIT(via_mc97_codecs)
{
    PCI_SET_DATA(PCI_ID_REG, PCI_ID_CODE(0x1106, 0x3068));
    PCI_SET_DATA(PCI_COMMAND_STATUS_REG, 0x02000030);
    PCI_SET_DATA(0x08, 0x07800000);
    PCI_SET_DATA(0x10, 0x00000001);
    PCI_SET_DATA(0x14, 0x00000001);
    PCI_SET_DATA(0x3c, 0x00000300);
    PCI_SET_DATA(0x40, 0x1c000000);

    PCI_SET_DATA_SIZE(0x10, 0xffffff01);
    PCI_SET_DATA_SIZE(0x14, 0xffffffff);
    PCI_SET_DATA_SIZE(0x18, 0xffffffff);
    PCI_SET_DATA_SIZE(0x1c, 0xffffffff);
    PCI_SET_DATA_SIZE(0x20, 0xffffffff);
    PCI_SET_DATA_SIZE(0x24, 0xffffffff);
}
