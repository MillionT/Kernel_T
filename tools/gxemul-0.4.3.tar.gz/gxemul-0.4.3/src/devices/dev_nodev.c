/*
 *  Copyright (C) 2004-2006  Anders Gavare.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright  
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE   
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *   
 *
 *  
 *   Access unaddressable space
 *   *
 *  TODO:  Actually implement this device.  So far it's just a fake device
 *         to allow Linux to print stuff to the console.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "console.h"
#include "device.h"
#include "machine.h"
#include "memory.h"
#include "misc.h"
#define NO_DEV_LENGTH	0x10

struct nodev_data {
	char *name;
};

DEVICE_ACCESS(nodev)
{
	uint64_t idata = 0, odata = 0;
	struct nodev_data *d = extra;
	
	if (writeflag == MEM_WRITE) {
		idata = memory_readmax64(cpu, data, len);
		debug("[ %s: cpu write %08llx to device %s addr %08llx ]\n", idata, d->name, relative_addr);
	}
	else if (writeflag == MEM_READ) {
		odata = 0;
		memory_writemax64(cpu, data, len, odata);
	}

	return 1;
}

DEVINIT(nodev)
{
	char *name;
	struct nodev_data *d;
	int nlen = 100;
	d = malloc(sizeof(struct nodev_data));
	if (d == NULL) {
		fprintf(stderr, "out of memory\n");
		exit(1);
	}
	memset(d, 0, sizeof(struct nodev_data));
	d->name = devinit->name2 != NULL? devinit->name2 : "";
	name = malloc(nlen);
	if (name == NULL) {
		fprintf(stderr, "out of memory\n");
		exit(1);
	}
	if (devinit->name2 != NULL && devinit->name2[0])
		snprintf(name, nlen, "%s [%s]", devinit->name, devinit->name2);
	else
		snprintf(name, nlen, "%s", devinit->name);

	/* Ugly, fix me!! */
	memory_device_register(devinit->machine->memory, name,
	    devinit->addr, NO_DEV_LENGTH, dev_nodev_access, d, DM_DEFAULT, NULL);
	return 1;
}
